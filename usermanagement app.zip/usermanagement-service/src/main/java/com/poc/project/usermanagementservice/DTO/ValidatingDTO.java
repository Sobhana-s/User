package com.poc.project.usermanagementservice.DTO;

import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ValidatingDTO {
    @Id
    @JsonProperty
    private boolean validStatus;

	public boolean isValidStatus() {
		return validStatus;
	}

	public void setValidStatus(boolean validStatus) {
		this.validStatus = validStatus;
	}

	public ValidatingDTO(boolean validStatus) {
		super();
		this.validStatus = validStatus;
	}
	public ValidatingDTO() {
		
	}
}
