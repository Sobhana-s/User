package com.poc.project.usermanagementservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.poc.project.usermanagementservice.DTO.ValidatingDTO;
import com.poc.project.usermanagementservice.exception.UnauthourizedException;
import com.poc.project.usermanagementservice.exception.UserNotFoundException;
import com.poc.project.usermanagementservice.model.AuthenticationResponse;
import com.poc.project.usermanagementservice.model.UserDto;
import com.poc.project.usermanagementservice.model.Userdao;
import com.poc.project.usermanagementservice.repository.UserRepository;
import com.poc.project.usermanagementservice.service.UserService;
import com.poc.project.usermanagementservice.util.JwtUtil;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired 
    private JwtUtil jwtTokenUtil;
	@Autowired
	private UserRepository repo;
	private ValidatingDTO validatingDTO = new ValidatingDTO();
 @PostMapping("/adduser")
 public ResponseEntity<AuthenticationResponse> addUser(@RequestBody Userdao user) {
	 
	 UserDetails userDetails = userService.addUser(user);
	 
	 return new ResponseEntity<AuthenticationResponse>(new AuthenticationResponse(user.getName(), jwtTokenUtil.generateToken(userDetails), jwtTokenUtil.getCurrentTime(), jwtTokenUtil.getExpirationTime()), HttpStatus.OK);
 }
 	@GetMapping(path = "/validate", produces = MediaType.APPLICATION_JSON_VALUE)
     public ResponseEntity<ValidatingDTO> validatingAuthorizationToken(
     @RequestHeader(name = "Authorization") String tokenDup) throws Exception {
     String token = tokenDup.substring(7);
     try {
     UserDetails user = userService.loadUserByUsername(jwtTokenUtil.extractUsername(token));
     if (Boolean.TRUE.equals(jwtTokenUtil.validateToken(token, user))) {
     validatingDTO.setValidStatus(true);
     return new ResponseEntity<>(validatingDTO, HttpStatus.OK);
     } else {
    	 throw new UnauthourizedException("Invalid Token");}
  } catch (Exception e) {
		 validatingDTO.setValidStatus(false);
		 return new ResponseEntity<>(validatingDTO, HttpStatus.OK);
		 }
		 }

 @GetMapping("/getallusers")
 public ResponseEntity<List<Userdao>> getUser(@RequestHeader(name = "Authorization") String tokenDup) throws Exception {
 String token = tokenDup.substring(7);
 UserDetails user = userService.loadUserByUsername(jwtTokenUtil.extractUsername(token));
 Userdao userDao = repo.getUserByName(user.getUsername()).orElse(null);
 if(userDao.getRole().equals("ROLE_ADMIN")) {
 if (Boolean.TRUE.equals(jwtTokenUtil.validateToken(token, user))) {
 validatingDTO.setValidStatus(true);
  return new ResponseEntity<List<Userdao>>(userService.getUser(),HttpStatus.ACCEPTED);
 }
throw new UnauthourizedException("Username or Password is not valid");
}
 
 
 
throw new UserNotFoundException("User doesn't have access for this page");

 }
 @PutMapping("/putuser")
 public ResponseEntity<Userdao> putUser(@RequestBody Userdao userDao , @RequestHeader(name= "Authorization") String tokenDup) throws Exception{
	 String token = tokenDup.substring(7);
	 UserDetails user = userService.loadUserByUsername(jwtTokenUtil.extractUsername(token));
	 Userdao userDao1 = repo.getUserByName(user.getUsername()).orElse(null);
	 if(userDao1.getRole().equals("ROLE_ADMIN")) {
	 if (Boolean.TRUE.equals(jwtTokenUtil.validateToken(token, user))) {
	 validatingDTO.setValidStatus(true);
	  return new ResponseEntity<Userdao>(userService.putUser(userDao),HttpStatus.ACCEPTED);
	 }
	throw new UnauthourizedException("Username or Password is not valid");
 }
		throw new UserNotFoundException("User doesn't have access for this page");
 }
 
 @DeleteMapping("/deleteuser/{id}")
 public ResponseEntity<String> deleteUser(@PathVariable int id, @RequestHeader(name= "Authorization") String tokenDup) throws Exception{
	 String token = tokenDup.substring(7);
	 UserDetails user = userService.loadUserByUsername(jwtTokenUtil.extractUsername(token));
	 Userdao userDao1 = repo.getUserByName(user.getUsername()).orElse(null);
	 if(userDao1.getRole().equals("ROLE_ADMIN")) {
	 if (Boolean.TRUE.equals(jwtTokenUtil.validateToken(token, user))) {
	 validatingDTO.setValidStatus(true);
	  return new ResponseEntity<String>(userService.deleteUser(id),HttpStatus.ACCEPTED);
	 }
	throw new UnauthourizedException("Username or Password is not valid");
	}
	throw new UserNotFoundException("User doesn't have access for this page");
}
 @PostMapping("/login")
public ResponseEntity<AuthenticationResponse> createAuthorizationToken(
@RequestBody Userdao userDao) throws Exception
{
final UserDetails userDetails = userService.loadUserByUsername(userDao.getName());
if (userDetails.getPassword().equals(userDao.getPassword())) {
return new ResponseEntity<AuthenticationResponse>(new AuthenticationResponse(userDao.getName(),
jwtTokenUtil.generateToken(userDetails), jwtTokenUtil.getCurrentTime(), jwtTokenUtil.getExpirationTime()), HttpStatus.OK);
}
throw new UnauthourizedException("Username or password is invalid");

 }
 @GetMapping("/loggedInUser")

public ResponseEntity<UserDto> getLoggedInUser(@RequestHeader(name = "Authorization") String tokenDup){
String token = tokenDup.substring(7);
UserDetails user = userService.loadUserByUsername(jwtTokenUtil.extractUsername(token));
Userdao userDao = repo.getUserByName(user.getUsername()).orElse(null);
UserDto userDto = new UserDto();
userDto.setId(userDao.getId());
userDto.setName(userDao.getName());
userDto.setRole(userDao.getRole());
userDto.setEmailId(userDao.getEmailId());
userDto.setPassword(userDao.getPassword());
return new ResponseEntity<UserDto>(userDto, HttpStatus.ACCEPTED);
}
}
