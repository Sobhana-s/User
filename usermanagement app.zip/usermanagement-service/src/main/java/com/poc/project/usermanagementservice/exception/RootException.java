package com.poc.project.usermanagementservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class RootException {
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException unDefinedException){
		return new ResponseEntity<String>(unDefinedException.getMessage(),HttpStatus.BAD_REQUEST);
		}
	@ExceptionHandler(UserNameExistException.class)
	public ResponseEntity<String> handleUserNameExistException(UserNameExistException unDefinedException){
		return new ResponseEntity<String>(unDefinedException.getMessage(),HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(UnauthourizedException.class)
	public ResponseEntity<String> handleUnauthourizedException(UnauthourizedException unDefinedException){
		return new ResponseEntity<String>(unDefinedException.getMessage(),HttpStatus.BAD_REQUEST);
		}
@ExceptionHandler(Exception.class)
public ResponseEntity<String> handleUndefinedException(Exception unDefinedException){
	return new ResponseEntity<String>(unDefinedException.getMessage(),HttpStatus.BAD_REQUEST);
	}
}
