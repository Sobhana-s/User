package com.poc.project.usermanagementservice.exception;

public class UserNameExistException extends RuntimeException{
		  private String message;

		public UserNameExistException(String message) {
			super();
			this.message = message;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public UserNameExistException () {
			
		}

}
