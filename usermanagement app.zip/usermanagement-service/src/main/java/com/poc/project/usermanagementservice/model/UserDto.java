package com.poc.project.usermanagementservice.model;

public class UserDto {
	
	    private int id;
		public UserDto(int id, String name, String role, String emailId, String password) {
			super();
			this.id = id;
			this.name = name;
			this.role = role;
			this.emailId = emailId;
			this.password = password;
		}
		public UserDto() {
			
		}
		private String name;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}

		private String role;
		private String emailId;
	
		private String password;
	}

