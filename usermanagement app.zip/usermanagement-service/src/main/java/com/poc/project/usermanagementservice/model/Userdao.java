package com.poc.project.usermanagementservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@javax.persistence.Entity(name="persons")
@javax.persistence.Table(name="persons")
public class Userdao {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	public Userdao(int id, String name, String role, String emailId, String password) {
		super();
		this.id = id;
		this.name = name;
		this.role = role;
		this.emailId = emailId;
		this.password = password;
	}
	public Userdao() {
		
	}
	@Column
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column
	private String role;
	@Column
	private String emailId;
	@Column
	private String password;
}
