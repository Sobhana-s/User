package com.poc.project.usermanagementservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.project.usermanagementservice.model.Userdao;

public interface UserRepository extends JpaRepository<Userdao, Integer>
{
   public Optional<Userdao> getUserByName(String name);
}
