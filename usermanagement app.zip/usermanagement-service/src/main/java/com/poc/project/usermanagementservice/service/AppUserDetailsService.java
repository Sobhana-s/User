package com.poc.project.usermanagementservice.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.poc.project.usermanagementservice.model.Userdao;
import com.poc.project.usermanagementservice.repository.UserRepository;

import antlr.collections.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;

@Service
@Slf4j
public class AppUserDetailsService implements UserDetailsService {

	@Autowired
	//RequestRepo authRequestRepo;
	UserRepository authRequestRepo;


     @Override
     public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException{
    	// List<GrantedAuthority> roles = null;
    	 Userdao user = authRequestRepo.getUserByName(userName).orElse(null);
    	 if(user != null) {
      //   roles = Arrays.asList(new SimpleGrantedAuthority(user.getRole()));
         UserDetails userDetails = new User( user.getName() , user.getPassword(),new ArrayList<>());
         return userDetails;
         }
    	 throw new UsernameNotFoundException("User not found!!");
    	 }
}