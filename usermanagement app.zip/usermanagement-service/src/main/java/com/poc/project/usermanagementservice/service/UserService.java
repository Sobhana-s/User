package com.poc.project.usermanagementservice.service;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.poc.project.usermanagementservice.exception.UserNameExistException;
import com.poc.project.usermanagementservice.exception.UserNotFoundException;
import com.poc.project.usermanagementservice.model.Userdao;
import com.poc.project.usermanagementservice.repository.UserRepository;


@Service
public class UserService {
@Autowired 
private UserRepository userRepository;
public UserDetails addUser(Userdao user) {
		Userdao userdaoo = userRepository.getUserByName(user.getName()).orElse(null);
		if(userdaoo == null) {
	userRepository.save(user);
	 UserDetails userDetails = new User( user.getName() , user.getPassword(),new ArrayList<>());
     return userDetails;
		}
		throw new UserNameExistException("User name exist exception");
}
public java.util.List<Userdao> getUser() {
	// TODO Auto-generated method stub
	return userRepository.findAll();

	
}
public Userdao putUser(Userdao user) {
	// TODO Auto-generated method stub
    Userdao update = userRepository.findById(user.getId()).orElse(null);
    if (update != null) {
    	Userdao up = userRepository.findById(user.getId()).get();
    	up.setName(user.getName());
    	up.setEmailId(user.getEmailId());
    	up.setPassword(user.getPassword());
    	up.setRole(user.getRole());
    	return userRepository.save(up);
    }
    throw new UserNotFoundException("User not found");

}
public String deleteUser(int id) {
	// TODO Auto-generated method stub
	 Userdao update = userRepository.findById(id).orElse(null);
	    if (update != null) {
	    userRepository.deleteById(id);
	    return "User deleted successfully..";
	    }
	    throw new UserNotFoundException("User not found");
}
public UserDetails loadUserByUsername(String extractUsername) {
	// TODO Auto-generated method stub
		Userdao user = userRepository.getUserByName(extractUsername).orElse(null);
    if(user != null) {
	UserDetails userDetails = new User( user.getName() , user.getPassword(), new ArrayList<>());
	return userDetails;
	}
   throw new UsernameNotFoundException("User not found!!");
}
}
