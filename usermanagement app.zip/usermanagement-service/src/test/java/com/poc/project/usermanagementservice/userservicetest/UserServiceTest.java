package com.poc.project.usermanagementservice.userservicetest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Optional;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

import com.poc.project.usermanagementservice.exception.UserNameExistException;
import com.poc.project.usermanagementservice.exception.UserNotFoundException;
import com.poc.project.usermanagementservice.model.Userdao;
import com.poc.project.usermanagementservice.repository.UserRepository;
import com.poc.project.usermanagementservice.service.UserService;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
@InjectMocks // helpful for main class testing
private UserService userService;
@Mock // to test the repository
private UserRepository userRepository;
@Test
public void addUserTest() {
Userdao userDao = new Userdao(6,"Ghijk","Analyst","abcde@gmail.com","hdjsdhsgd");
UserDetails actualString = userService.addUser(userDao);
UserDetails userDetails = new User( userDao.getName() , userDao.getPassword(), new ArrayList<>());
assertEquals(actualString, userDetails);
}

@Test
public void loadUserByNameTest() {
		 Userdao userDao = new Userdao(6,"Ghijk","Analyst","abcde@gmail.com","hdjsdhsgd");
		 given(userRepository.getUserByName("Ghijk")).willReturn(Optional.of(userDao));
	     UserDetails actualString = userService.loadUserByUsername(userDao.getName());
		UserDetails userDetails = new User( userDao.getName() , userDao.getPassword(),
		new ArrayList<>());
		assertEquals(actualString, userDetails);
		}
		
	@Test(expected = UserNameExistException.class)
	 public void userAlreadyExistsExceptionTest() {
	 Userdao userDao = new Userdao(6, "Mnopqr","Lead","mnopqr@gmail.com","hdjsdhsgd");
	 Optional<Userdao> userRes = Optional.of(userDao);
	  given(userRepository.getUserByName("Mnopqr")).willReturn(userRes);
	UserDetails actualString = userService.addUser(userDao);
	}
		
		@Test(expected = UserNotFoundException.class)
		public void userNotFoundExceptionTest() {
		Userdao userDao = new Userdao(6, "Mnopqr","Lead","mnopqrs@gmail.com","hdjsdhsgd");
		when(userRepository.findById(6).orElse(null)).thenThrow(new UserNotFoundException());
		Userdao actualString = userService.putUser(userDao);
	}
		
	
}